<footer class="py-4 shadow-sm text-white bg-dark mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row">
            <div class="col-auto"><div class="small m-0">Copyright &copy; Your Website 2023</div></div>
        </div>
    </div>
</footer>
