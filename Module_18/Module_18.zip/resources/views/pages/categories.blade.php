@extends('app')

@section('content')

@include('components.category_data')

@endsection