@extends('app')

@section('content')

@include('components.posts')

@endsection